package com.uis.taskmanager;

import java.io.File;

public interface Constants {
	int PRIORITY1 = 1;
	int PRIORITY2 = 5;
	int PRIORITY3 = 10;
	File PATH = new File("C:\\Eclipse\\TaskManager\\TaskDirectory");
}
